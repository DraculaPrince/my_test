import React from 'react'
import { Switch, withRouter } from 'react-router-dom'
import { observer } from 'mobx-react'
import routes, { RouteWithSubRoutes } from './routes'
import './assets/styles/Base.css'

function App () {
	return (
		<Switch>
			{
				routes.map((route, i) => (
					<RouteWithSubRoutes key={i} {...route}/>
				))
			}
		</Switch>
	)
}

export default withRouter(observer(App))
