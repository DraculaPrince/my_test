import http from '../util/http'

// 通过物联网卡号获取用户信息接口
export function getBCallUserInfoApi(vehiclePhone){
	return http.post('?s=App.BCall_BCall.UserInfo',{
		vehiclePhone
	})
}