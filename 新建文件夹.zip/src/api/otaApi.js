import http from '../util/http'

// 售后升级监控
export function getOtaUpgradeCvInfoApi(vin){
  return http.get('?s=App.OtaService_Ota.UpgradeCv',{
    vin
  })
}
// 售后车模块升级监控
export function getOtaUpgradeResultInfoApi(vin){
  return http.get('?s=App.OtaService_Ota.UpgradeResult',{
    vin
  })
}
//重要模块售后监控
export function getOtaUpMonitoringInfoApi(vin){
  return http.get('?s=App.OtaService_Ota.UpMonitoring',{
    vin
  })
}