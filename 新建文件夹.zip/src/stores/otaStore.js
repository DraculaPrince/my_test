import {
  getOtaUpgradeCvInfoApi,
  getOtaUpgradeResultInfoApi,
  getOtaUpMonitoringInfoApi
} from "../api/otaApi";
import {runInAction} from "mobx";

export const OtaStore = () => ({
  otaUpgradeCvInfo: [],
  otaUpgradeResultInfo: [],
  otaUpMonitoringInfo: [],
  //售后升级监控
  async getOtaUpgradeCvInfo(vin) {
    try {
      const res = await getOtaUpgradeCvInfoApi(vin)
      console.log(`getOtaUpgradeCvInfo: ${res}`)
      if (res) {
        runInAction(() => {
          this.otaUpgradeCvInfo = res
        })
      }
    } catch (err) {
      console.log(`getOtaUpgradeCvInfo fail: ${err}`)
    }
  },
  //售后车模块升级监控
  async getOtaUpgradeResultInfo(vin) {
    try {
      const res = await getOtaUpgradeResultInfoApi(vin)
      if (res) {
        runInAction(() => {
          this.otaUpgradeResultInfo = res
        })
      }
    } catch (err) {
      console.log(`getOtaUpgradeResultInfo fail: ${err}`)
    }
  },
  //重要模块售后监控
  async getOtaUpMonitoringInfo(vin){
    try{
      const res = await getOtaUpMonitoringInfoApi(vin)
      if (res) {
        runInAction(() => {
          this.otaUpMonitoringInfo = res
        })
      }
    }catch (err){
      console.log(`getOtaUpMonitoringInfo fail: ${err}`)
    }
  }
})