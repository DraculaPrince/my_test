import {getBCallUserInfoApi} from '../api/icallApi'
import {runInAction} from 'mobx'

export const IcallStore = () => (
  {
    bCallUserInfo: [],

    async getBCallUserInfo() {
      try {
        const res = await getBCallUserInfoApi('13096968945')
        console.log(`getBCallUserInfo: ${res}`)
        if (res) {
          runInAction(() => {
            this.bCallUserInfo = res
          })
        }
      } catch (err) {
        console.log(`getBCallUserInfo fail: ${err}`)
      }
    }
  }
)

