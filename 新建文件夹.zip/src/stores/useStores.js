import React from 'react'
import {storesContext} from './context'
import {IcallStore} from './icallStore'
import {OtaStore} from './otaStore'

export const useStores = () => React.useContext(storesContext)

export const publicStores = () => ({
  icallStore: IcallStore(),
  otaStore: OtaStore()
})