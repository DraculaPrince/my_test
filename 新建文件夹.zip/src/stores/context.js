import React from 'react'
import {IcallStore} from './icallStore'
import {OtaStore} from './otaStore'

export const storesContext = React.createContext({
  icallStore: IcallStore(),
  otaStore: OtaStore()
})
