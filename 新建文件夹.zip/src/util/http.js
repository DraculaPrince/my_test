import axios from 'axios'
import { ERROR_CODE } from './constant'

const http = axios.create({
	// baseURL: 'http://10.3.121.132',
	baseURL: 'http://10.166.1.118',
	timeout: 20000,
	headers: {
		'Content-Type': 'application/json;charset=utf-8',
	}
})

http.interceptors.request.use(async (config)=>{
	return config
}, error =>{
	return Promise.reject(error)
})

http.interceptors.response.use(response => {
	if (response && [...ERROR_CODE].indexOf(response.ret) === -1) {
		return typeof response.data !== 'undefined' && response.data !== null ? response.data : response
	}else {
		return Promise.reject(response)
	}
}, error => {
	return Promise.reject(error)
})

export default http