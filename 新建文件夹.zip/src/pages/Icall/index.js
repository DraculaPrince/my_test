import React, {useEffect} from 'react'
import {observer} from 'mobx-react'
import {useStores} from '../../stores/useStores'
import styles from './Icall.module.css'
import { Input, Button, Select, Timeline   } from 'antd';
import { SearchOutlined } from '@ant-design/icons';
import baiduMap from './baidumap.png';
import BikeMap from './bikeMap'

const Icall: React.FC = () => {
	const {icallStore} =useStores()
	useEffect(()=>{
		(async function getData(){
			await icallStore.getBCallUserInfo()
		})()
	})
  const { Search } = Input;
  const { Option } = Select;
	return (
		<>
			<h1 className={`${styles["my-p"]}`}>ICall</h1>
      <div className={`${styles['call-container']}`}>
          <div className={`${styles['left-container']}`}>
            <Input
              placeholder="物联网卡号"
              suffix={<SearchOutlined/>}
              style={{ width: 260 }}
            />
            <Button type="primary" className={`${styles['buttonStyle']}`}>搜索</Button>
            <h4 className={`${styles['h4Style']}`}>车主信息</h4>
            <p><span className={`${styles['spanStyle']}`}>车架号：</span><span className={`${styles['spanStyle']}`}>LC0CD4C44K1004658</span></p>
            <p><span className={`${styles['spanStyle']}`}>手机号码：</span><span className={`${styles['spanStyle']}`}>15001260000</span></p>
            <p><span className={`${styles['spanStyle']}`}>车主姓名：</span><span className={`${styles['spanStyle']}`}>张三</span></p>
            <p><span className={`${styles['spanStyle']}`}>当前位置：</span><span className={`${styles['spanStyle']}`}>深圳市</span></p>
            <div className={`${styles['blockDiv']}`}> </div>
            <div><span className={`${styles['selectStyle']}`}>地图类型</span>
              <Select defaultValue="bmap" style={{ width: 280 }}>
                <Option value="bmap">百度地图（默认）</Option>
                <Option value="amap">高德地图</Option>
              </Select>
            </div>
            <div><span className={`${styles['selectStyle']}`}>路线偏好</span>
              <Select defaultValue="intell" style={{ width: 280 }}>
                <Option value="intell">智能推荐（默认）</Option>
                <Option value="hsPolicy">高速优先</Option>
                <Option value="noHS">不走高速</Option>
                <Option value="noTraffic">避免拥堵</Option>
              </Select>
            </div>
            <div><span className={`${styles['selectStyle']}`}>目的地</span>
              <Search
                placeholder="输入目的地"
                enterButton="搜索"
                style={{width: 280}}
                onSearch={value => console.log(value)}
              />
            </div>
            <div><span className={`${styles['selectStyle']}`}>周边搜索</span>
              <Search
                placeholder="输入周边地点"
                enterButton="搜索"
                style={{ width: 280 }}
                onSearch={value => console.log(value)}
              />
            </div>
            <div><span className={`${styles['selectStyle']}`}> </span>
              <Button type="primary" className={`${styles['linebuttonleft']}`}>下发导航</Button>
              <Button className={`${styles['linebuttonright']}`}>刷新</Button>
            </div>
            <div className={`${styles['timelineDiv']}`}><span className={`${styles['selectStyle']}`}>下发进度</span>
              <Timeline className={`${styles['timelineStyle']}`}>
                <Timeline.Item>导航已推送      09:26:53</Timeline.Item>
                <Timeline.Item>车机已接收      10:26:53</Timeline.Item>
                <Timeline.Item>路径已规划      10:30:31</Timeline.Item>
              </Timeline>
            </div>
          </div>
          <div className={`${styles['right-container']}`}>
            <BikeMap />
            {/*<img src={baiduMap} alt=""/>*/}
          </div>
      </div>
		</>
	)
}

export default observer(Icall)