import React, {useEffect} from 'react'

export default function BikeMap (){
	const MP = (ak) => {
		return new Promise(function(resolve, reject) {
			var script = document.createElement('script')
			script.type = 'text/javascript'
			script.src = `http://api.map.baidu.com/api?v=2.0&ak=${ak}&callback=init`;
			document.head.appendChild(script)
			window.init = () => {
				resolve(window.BMap)
			}
		})
	}

	useEffect(()=>{
		MP("RYrqfC7AtITBsbhruGVwgVGSYpbiqFWg").then(BMap=>{
			let map = new BMap.Map('allmap');            // 创建Map实例
      let geoc = new BMap.Geocoder();
			let point = new BMap.Point(108.851532, 34.186355); // 创建点坐标
      let marker = new BMap.Marker(point);        // 创建标注
      // map.addControl(new BMap.MapTypeControl({
      //   mapTypes: [
      //     BMAP_NORMAL_MAP,
      //     // BMAP_HYBRID_MAP
      //   ]
      // }));
      map.enableScrollWheelZoom(true);      //开启鼠标滚轮缩放
      map.centerAndZoom(point, 15);         //地图层级
      map.addOverlay(marker);               // 将标注添加到地图中

      //byd测试经纬度
      let bydTest = {
        lat: 108.851532,
        lng: 34.186355,
        of: "inner"
      }
      map.addOverlay(new BMap.Point(108.851532, 34.186355))

      geoc.getLocation(new BMap.Point(108.851532, 34.186355), function (rs) {
        console.log('rs', rs)
        //addressComponents对象可以获取到详细的地址信息
        let addComp = rs.addressComponents;
        console.log('省', addComp.province)
        console.log('市', addComp.city)
        console.log('区', addComp.district)
        console.log('街道', addComp.street)
        console.log('街道号码', addComp.streetNumber)
      });
		})
	},[])

	return(
		<div>
			<div id='allmap' style={{width:800,height:600}}></div>
		</div>
	)
}