import React from 'react'
import {observer} from 'mobx-react'
import styles from './ServiceInfo.module.css'
import {
	PageHeader,
	Form,
	Row,
	Col,
	Input,
	Button,
	Select,
	Table,
	Drawer,
	Divider,
	Typography,
	Popconfirm,
} from 'antd';

const { Option } = Select;
const { Title  } = Typography;
//导航
const routes = [
	{
		path: 'index',
		breadcrumbName: '合作伙伴',
	},
	{
		path: 'first',
		breadcrumbName: '服务店信息',
	},
];

//查询组件
const AdvancedSearchForm = () => {
	const [form] = Form.useForm();
	//查询重置
	const onReset = () => {
		form.resetFields();
	};
	//查询确定
	const onFinish = values => {
		console.log(values);
	};
	return (
		<>
			<Form
				form={form}
				name="advanced_search"
				labelAlign="left"
				labelCol={{ span: 6 }}
				onFinish={onFinish}>
				<Row gutter={24}>
					<Col span={6}>
						<Form.Item
							label="省份"
							name="username"
							colon={false}>
							<Select>
							</Select>
						</Form.Item>
					</Col>

					<Col span={6}>
						<Form.Item
							label="市"
							name="username"
							colon={false}>
							<Select>
							</Select>
						</Form.Item>
					</Col>

					<Col span={6}>
						<Form.Item
							label="县/镇/区"
							name="username"
							colon={false}>
							<Select>
							</Select>
						</Form.Item>
					</Col>

					<Col span={6}>
						<Form.Item
							label="县/镇/区"
							name="username"
							colon={false}>
							<Select>
							</Select>
						</Form.Item>
					</Col>

					<Col span={6}>
						<Form.Item
							label="车型权限"
							name="username"
							colon={false}>
							<Input />
						</Form.Item>
					</Col>

					<Col span={6}>
						<Form.Item
							label="服务店名称"
							name="username"
							colon={false}>
							<Input  />
						</Form.Item>
					</Col>

					<Col span={6}>
						<Form.Item
							label="服务店编码"
							name="username"
							colon={false}>
							<Input />
						</Form.Item>
					</Col>

					<Col span={6}>
						<Form.Item
							label="售后区域"
							name="username"
							colon={false}>
							<Input />
						</Form.Item>
					</Col>

					<Col span={6}>
						<Button type="primary" htmlType="submit">
							查询
						</Button>
						<Button style={{ margin: '0 8px' }} onClick={onReset}>
							重置
						</Button>
					</Col>
				</Row>
			</Form>
		</>
	)
}

//table组件
class DataTable extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			selectedRowKeys: [], // Check here to configure the default column
			selectedRows: [],
			loading: false,
			visible: false,
			data: [
				{
					key: 'name',
					name: 'John Brown',
					age: 32,
					address: 'New York Park',
				},
				{
					key: 'age',
					name: 'Jim Green',
					age: 40,
					address: 'London Park',
				},
			],
		};
		//列表
		this.columns = [
			{
				title: '服务店编码',
				dataIndex: 'address',
				key: '1',
				width: 110,
				fixed: 'left',
			},
			{
				title: '大区',
				dataIndex: 'address',
				key: '2',
				width: 100,
				fixed: 'left',
			},
			{ title: '区域', dataIndex: 'address', key: '3' },
			{ title: '省份', dataIndex: 'address', key: '4' },
			{ title: '市', dataIndex: 'address', key: '5' },
			{ title: '县/镇/区', dataIndex: 'address', key: '6' },
			{ title: '城市类别', dataIndex: 'address', key: '7' },
			{ title: '售后经理', dataIndex: 'address', key: '8' },
			{ title: '大区督导', dataIndex: 'address', key: '9' },
			{ title: '大区技术督导', dataIndex: 'address', key: '10' },
			{ title: '状态栏', dataIndex: 'address', key: '10' },
			{ title: '等级', dataIndex: 'address', key: '10' },
			{
				title: '操作',
				key: 'operation',
				fixed: 'right',
				width: 120,
				render: (index) =>{
					return (
						<div className={`${styles["operation-btn"]}`}>
							<a>详情</a>
							<Popconfirm
								placement="topRight"
								title="删除不可恢复，确定要删除吗?"
								onConfirm={this.onDelete.bind(this,index)}
								okText="确定"
								cancelText="取消"
							>
								<a>删除</a>
							</Popconfirm>
						</div>
					)
				}
			},
		];
		this.onDelete = this.onDelete.bind(this);
		this.handleSelectedDelete = this.handleSelectedDelete.bind(this);
	}

	onDelete(index){
		console.log(index)
		const data = [...this.state.data];
		data.splice(index, 1);//index为获取的索引，后面的 1 是删除几行
		this.setState({ data });
	}


	handleSelectedDelete(){
		this.setState({
			loading: true
		});
		setTimeout(() => {
			if(this.state.selectedRowKeys.length>0){
				const data = [...this.state.data]
				data.splice(this.state.selectedRowKeys,this.state.selectedRowKeys.length)
				this.setState({
					data,
					selectedRowKeys: [],
					loading: false,
				});
			}
		}, 1000);
	}


	showDrawer = () => {
		this.setState({
			visible: true,
		});
	};

	onClose = () => {
		this.setState({
			visible: false,
		});
	};

	selectRow = () => {
		this.setState({
			loading: true
		});
		// ajax request after empty completing
		setTimeout(() => {
			this.setState({
				selectedRowKeys: [],
				loading: false,
			});
		}, 1000);
	};

	onSelectChange = selectedRowKeys => {
		console.log('selectedRowKeys changed: ', selectedRowKeys);
		this.setState({ selectedRowKeys });
	};

	render() {
		const { loading, selectedRowKeys } = this.state;
		const rowSelection = {
			selectedRowKeys,
			onChange: this.onSelectChange,
		};
		const hasSelected = selectedRowKeys.length > 0;
		return (
			<div className={`${styles["table-box"]}`}>
				<div className={`${styles["action-box"]}`}>
					<Button type="primary" onClick={this.showDrawer}>
						新增
					</Button>
					<Button type="primary" onClick={this.handleSelectedDelete} disabled={!hasSelected} loading={loading}>
						批量删除
					</Button>
				</div>
				<Table rowSelection={rowSelection} columns={this.columns} dataSource={this.state.data} scroll={{ x: 1500, y: 1300 }} />
				<Drawer
					title="新增"
					width={720}
					onClose={this.onClose}
					visible={this.state.visible}
					bodyStyle={{ paddingBottom: 80 }}
					footer={
						<div
							style={{
								textAlign: 'left',
							}}
						>
							<Button onClick={this.onClose} style={{ marginRight: 8 }}>
								确定
							</Button>
							<Button onClick={this.onClose} type="primary">
								取消
							</Button>
						</div>
					}
				>
					<Form
						  labelAlign="left"
						  labelCol={{ span: 8 }}>
						<Title level={4}>基本信息</Title>
						<Row gutter={16}>
							<Col span={12}>
								<Form.Item
									name="name"
									label="服务店代码"
									rules={[{ required: true }]}
								>
									<Input  />
								</Form.Item>
							</Col>
							<Col span={12}>
								<Form.Item
									name="url"
									label="服务店名称"
									rules={[{ required: true}]}
								>
									<Input />
								</Form.Item>
							</Col>
						</Row>
						<Row gutter={16}>
							<Col span={12}>
								<Form.Item
									name="owner"
									label="Owner"
									rules={[{ required: true, message: 'Please select an owner' }]}
								>
									<Select placeholder="Please select an owner">
										<Option value="xiao">Xiaoxiao Fu</Option>
										<Option value="mao">Maomao Zhou</Option>
									</Select>
								</Form.Item>
							</Col>
							<Col span={12}>
								<Form.Item
									name="type"
									label="Type"
									rules={[{ required: true, message: 'Please choose the type' }]}
								>
									<Select placeholder="Please choose the type">
										<Option value="private">Private</Option>
										<Option value="public">Public</Option>
									</Select>
								</Form.Item>
							</Col>
						</Row>
						<Row gutter={16}>
							<Col span={12}>
								<Form.Item
									name="approver"
									label="Approver"
									rules={[{ required: true, message: 'Please choose the approver' }]}
								>
									<Select placeholder="Please choose the approver">
										<Option value="jack">Jack Ma</Option>
										<Option value="tom">Tom Liu</Option>
									</Select>
								</Form.Item>
							</Col>
						</Row>
						<Row gutter={16}>
							<Col span={24}>
								<Form.Item
									name="description"
									label="Description"
									rules={[
										{
											required: true,
											message: 'please enter url description',
										},
									]}
								>
									<Input.TextArea rows={4} placeholder="please enter url description" />
								</Form.Item>
							</Col>
						</Row>
						<Divider />
						<Title level={4}>服务店地址与负责人信息</Title>
						<Row gutter={16}>
							<Col span={12}>
								<Form.Item
									name="name"
									label="Name"
									rules={[{ required: true, message: 'Please enter user name' }]}
								>
									<Input placeholder="Please enter user name" />
								</Form.Item>
							</Col>
							<Col span={12}>
								<Form.Item
									name="url"
									label="Url"
									rules={[{ required: true, message: 'Please enter url' }]}
								>
									<Input
										style={{ width: '100%' }}
										addonBefore="http://"
										addonAfter=".com"
										placeholder="Please enter url"
									/>
								</Form.Item>
							</Col>
						</Row>
						<Row gutter={16}>
							<Col span={12}>
								<Form.Item
									name="owner"
									label="Owner"
									rules={[{ required: true, message: 'Please select an owner' }]}
								>
									<Select placeholder="Please select an owner">
										<Option value="xiao">Xiaoxiao Fu</Option>
										<Option value="mao">Maomao Zhou</Option>
									</Select>
								</Form.Item>
							</Col>
							<Col span={12}>
								<Form.Item
									name="type"
									label="Type"
									rules={[{ required: true, message: 'Please choose the type' }]}
								>
									<Select placeholder="Please choose the type">
										<Option value="private">Private</Option>
										<Option value="public">Public</Option>
									</Select>
								</Form.Item>
							</Col>
						</Row>
						<Row gutter={16}>
							<Col span={12}>
								<Form.Item
									name="approver"
									label="Approver"
									rules={[{ required: true, message: 'Please choose the approver' }]}
								>
									<Select placeholder="Please choose the approver">
										<Option value="jack">Jack Ma</Option>
										<Option value="tom">Tom Liu</Option>
									</Select>
								</Form.Item>
							</Col>
						</Row>
						<Row gutter={16}>
							<Col span={24}>
								<Form.Item
									name="description"
									label="Description"
									rules={[
										{
											required: true,
											message: 'please enter url description',
										},
									]}
								>
									<Input.TextArea rows={4} placeholder="please enter url description" />
								</Form.Item>
							</Col>
						</Row>
					</Form>
				</Drawer>
			</div>
		);
	}
}

const ServiceInfo: React.FC = () => {
	return (
		<>
			<div>
				<PageHeader
					className="site-page-header"
					title="服务店信息"
					breadcrumb={{ routes }}
				/>
				<div className={`${styles["cont-box"]}`}>
					<AdvancedSearchForm/>
					<DataTable/>
				</div>
			</div>
		</>
	)
}

export default observer(ServiceInfo)