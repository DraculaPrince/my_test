import React from "react";
import {observer} from 'mobx-react';

import {
  Breadcrumb,
  Row,
  Col,
  Form,
  Select,
  Input,
  Button
} from 'antd'

import styles from './Dealer.module.css'

const {Option} = Select;

const Dealer: React.FC = () => {
  const formItemLayout = {
    labelCol: {span: 12},
    wrapperCol: {span: 16},
  };
  return (
    <>
      <div className={`${styles['container']}`}>
        <Row>
          <Col span={24}>
            <Breadcrumb>
              <Breadcrumb.Item>合作伙伴</Breadcrumb.Item>
              <Breadcrumb.Item>经销商查询</Breadcrumb.Item>
            </Breadcrumb>
          </Col>
        </Row>
        <Row>
          <Col span={24} className={`${styles["title"]}`}>
            经销商信息
          </Col>
        </Row>

        <Row>
          <Col span={24}>
            <Form {...formItemLayout} layout={'inline'} >
              <Col span={6}>
                <Form.Item  label="可销售车系">
                  <Select>
                    <Option value="china">China</Option>
                    <Option value="usa">U.S.A</Option>
                  </Select>
                </Form.Item>
              </Col>
              <Col span={6}>
                <Form.Item label="可销售车系A">
                  <Select>
                    <Option value="china">China</Option>
                    <Option value="usa">U.S.A</Option>
                  </Select>
                </Form.Item>
              </Col>
              <Col span={6}>
                <Form.Item label="营销中心">
                  <Select>
                    <Option value="china">China</Option>
                    <Option value="usa">U.S.A</Option>
                  </Select>
                </Form.Item>
              </Col>
              <Col span={6}>
                <Form.Item labelAlign={'left'} label="营销中心">
                  <Select>
                    <Option value="china">China</Option>
                    <Option value="usa">U.S.A</Option>
                  </Select>
                </Form.Item>
              </Col>
              {/*<Col span={6}>*/}
              {/*  <Form.Item label="营销中心">*/}
              {/*    <Select>*/}
              {/*      <Option value="china">China</Option>*/}
              {/*      <Option value="usa">U.S.A</Option>*/}
              {/*    </Select>*/}
              {/*  </Form.Item>*/}
              {/*</Col>*/}
            </Form>
          </Col>
        </Row>
        {/*<Row>*/}
        {/*  <Col span={24}>*/}

        {/*    <Form layout={'inline'}>*/}
        {/*      <Col span={6}>*/}
        {/*        <Form.Item label="营销中心">*/}
        {/*          <Select>*/}
        {/*            <Option value="china">China</Option>*/}
        {/*            <Option value="usa">U.S.A</Option>*/}
        {/*          </Select>*/}
        {/*        </Form.Item>*/}
        {/*      </Col>*/}
        {/*      <Col span={6}>*/}
        {/*        <Form.Item label="大区">*/}
        {/*          <Select>*/}
        {/*            <Option value="china">China</Option>*/}
        {/*            <Option value="usa">U.S.A</Option>*/}
        {/*          </Select>*/}
        {/*        </Form.Item>*/}
        {/*      </Col>*/}
        {/*      <Col span={6}>*/}
        {/*        <Form.Item label="区域">*/}
        {/*          <Select>*/}
        {/*            <Option value="china">China</Option>*/}
        {/*            <Option value="usa">U.S.A</Option>*/}
        {/*          </Select>*/}
        {/*        </Form.Item>*/}
        {/*      </Col>*/}
        {/*      <Col span={6}>*/}
        {/*        <Form.Item label="可销售车系">*/}
        {/*          <Select>*/}
        {/*            <Option value="china">China</Option>*/}
        {/*            <Option value="usa">U.S.A</Option>*/}
        {/*          </Select>*/}
        {/*        </Form.Item>*/}
        {/*      </Col>*/}
        {/*      <Col span={6}>*/}
        {/*        <Form.Item label="Field A">*/}
        {/*          <Select>*/}
        {/*            <Option value="china">China</Option>*/}
        {/*            <Option value="usa">U.S.A</Option>*/}
        {/*          </Select>*/}
        {/*        </Form.Item>*/}
        {/*      </Col>*/}
        {/*      <Col span={6}>*/}
        {/*        <Form.Item label="Field A">*/}
        {/*          <Input placeholder="input placeholder"/>*/}
        {/*        </Form.Item>*/}
        {/*      </Col>*/}
        {/*      <Col span={6}>*/}
        {/*        <Form.Item label="Field A">*/}
        {/*          <Input placeholder="input placeholder"/>*/}
        {/*        </Form.Item>*/}
        {/*      </Col>*/}
        {/*      <Col span={6}>*/}
        {/*        <Form.Item label="Field A">*/}
        {/*          <Input placeholder="input placeholder"/>*/}
        {/*        </Form.Item>*/}
        {/*      </Col>*/}
        {/*      <Col span={6}>*/}
        {/*        <Form.Item label="Field A">*/}
        {/*          <Input placeholder="input placeholder"/>*/}
        {/*        </Form.Item>*/}
        {/*      </Col>*/}
        {/*      <Col span={6}>*/}
        {/*        <Form.Item label="Field A">*/}
        {/*          <Input placeholder="input placeholder"/>*/}
        {/*        </Form.Item>*/}
        {/*      </Col>*/}
        {/*      <Col span={6}>*/}
        {/*        <Form.Item label="Field A">*/}
        {/*          <Input placeholder="input placeholder"/>*/}
        {/*        </Form.Item>*/}
        {/*      </Col>*/}
        {/*      <Col span={6}>*/}
        {/*        <Form.Item label="Field A">*/}
        {/*          <Input placeholder="input placeholder"/>*/}
        {/*        </Form.Item>*/}
        {/*      </Col>*/}
        {/*      <Col span={6}>*/}
        {/*        <Form.Item label="Field A">*/}
        {/*          <Input placeholder="input placeholder"/>*/}
        {/*        </Form.Item>*/}
        {/*      </Col>*/}
        {/*      <Col span={6}>*/}
        {/*        <Form.Item label="Field A">*/}
        {/*          <Input placeholder="input placeholder"/>*/}
        {/*        </Form.Item>*/}
        {/*      </Col>*/}
        {/*      <Col span={6}>*/}
        {/*        <Button type="primary">查询</Button>*/}
        {/*        <Button>重置</Button>*/}
        {/*      </Col>*/}
        {/*    </Form>*/}
        {/*  </Col>*/}
        {/*</Row>*/}
      </div>
    </>
  )
}

export default observer(Dealer)
