import React from 'react'
import { Spin } from 'antd'

const Loading: React.FC = () => {
	return (
		<>
			<Spin />
		</>
	)
}

export default Loading
