import React from 'react'
import {observer} from 'mobx-react'

import {
  Row,
  Col,
  Breadcrumb,
  Tabs,
} from 'antd';

import styles from './Ota.module.css'

import OtaAfterSale from './Ota.AfterSale'
import OtaAfterSaleCarModule from './Ota.AfterSaleCarModule'
import OtaAfterSaleImportantModule from "./Ota.AfterSaleImportantModule";

const {TabPane} = Tabs;

const Ota: React.FC = () => {
  return (
    <>
      <div className={`${styles["container"]}`}>
        <Row>
          <Col span={24}>
            <Breadcrumb>
              <Breadcrumb.Item>信息查询</Breadcrumb.Item>
              <Breadcrumb.Item>
                OTA
              </Breadcrumb.Item>
            </Breadcrumb>
          </Col>
        </Row>
        <Row>
          <Col span={24} className={`${styles["title"]}`}>
            OTA
          </Col>
        </Row>
        <Row>
          <Col span={24}>
            <Tabs defaultActiveKey="1" style={{marginBottom: 32}} type="card">
              <TabPane tab="售后升级监控" key="1">
                <OtaAfterSale />
              </TabPane>
              <TabPane tab="售后车模块升级监控" key="2">
                <OtaAfterSaleCarModule />
              </TabPane>
              <TabPane tab="重要模块售后升级监控" key="3">
                <OtaAfterSaleImportantModule />
              </TabPane>
            </Tabs>
          </Col>
        </Row>
      </div>
    </>
  )
}

export default observer(Ota)