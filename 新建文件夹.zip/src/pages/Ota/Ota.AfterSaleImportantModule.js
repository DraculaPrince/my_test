import React, {useState} from 'react'
import {observer} from 'mobx-react'
import {
  Row,
  Col,
  Input,
  Button,
  Table,
  Space,
  Drawer,
  Descriptions
} from 'antd';
import {SearchOutlined} from '@ant-design/icons';
import styles from './Ota.module.css'
import {important_data} from './test.data'

const OtaAfterSaleImportantModule: React.FC = () => {
  const [visible, setVisible] = useState(false);
  const [rowDetails, setRowDetails] = useState({});
  const onClose = () => {
    setVisible(false);
  };

  const details = (record) => {
    setRowDetails(record)
    setVisible(true);
  }
  const columns = [
    {
      title: '车架号',
      dataIndex: 'vin',
      key: 'vin',
      width: 200,
    },
    {
      title: '车型',
      dataIndex: 'carType',
      key: 'carType',
      width: 100,
    },
    {
      title: '模块名称',
      dataIndex: 'ecuName',
      key: 'ecuName',
      width: 150,
    },
    {
      title: '升级前版本',
      key: 'vehicleOriginVer',
      dataIndex: 'vehicleOriginVer',
      width: 100,
    },
    {
      title: '车辆升级时间',
      key: 'vehicleTime',
      dataIndex: 'vehicleTime',
      width: 150,
    },
    {
      title: '车辆升级失败原因',
      key: 'vehicleReason',
      dataIndex: 'vehicleReason',
      width: 400,
    },
    {
      title: '短信推送结果',
      key: 'success',
      dataIndex: 'success',
      width: 150,
    },
    {
      title: '短信推送失败原因',
      key: 'descr',
      dataIndex: 'descr',
      width: 400
    },
    {
      title: '更多',
      key: 'action',
      fixed: 'right',
      width: 80,
      render: (text, record) => (
        <Space size="middle">
          <a className={`${styles["action"]}`} onClick={() => details(record)}>详情</a>
        </Space>
      ),
    },
  ];
  return (
    <>
      <Row className={`${styles["search-row"]}`}>
        <Col span={4}>
          <Input placeholder="请输入车架号" suffix={<SearchOutlined/>}/>
        </Col>
        <Col span={8}>
          <Button type="primary">查询</Button>
          <Button>重置</Button>
        </Col>
      </Row>
      <Row>
        <Col span={24}>
          <Table size="middle" columns={columns}
                 dataSource={important_data} scroll={{x: 1200, y: 300}}/>
        </Col>
      </Row>
      <Drawer
        title="详情"
        placement="right"
        width={400}
        closable={false}
        onClose={onClose}
        visible={visible}
      >
        <Descriptions title="重要模块升级监控" column={1}>
          <Descriptions.Item label="车架号">{rowDetails.vin}</Descriptions.Item>
          <Descriptions.Item label="车型">{rowDetails.carType}</Descriptions.Item>
          <Descriptions.Item label="模块名称">{rowDetails.ecuName}</Descriptions.Item>
          <Descriptions.Item label="升级前版本">{rowDetails.vehicleOriginVer}</Descriptions.Item>
          <Descriptions.Item label="车辆升级时间">{rowDetails.vehicleTime}</Descriptions.Item>
          <Descriptions.Item label="车辆升级失败原因">{rowDetails.vehicleReason}</Descriptions.Item>
          <Descriptions.Item label="短信推送结果">{rowDetails.success}</Descriptions.Item>
          <Descriptions.Item label="短信推送失败原因">{rowDetails.descr}</Descriptions.Item>
        </Descriptions>
      </Drawer>
    </>
  )
}

export default observer(OtaAfterSaleImportantModule)