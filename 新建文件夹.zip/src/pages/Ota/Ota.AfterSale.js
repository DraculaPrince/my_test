import React, {useEffect, useState} from 'react'
import {observer} from 'mobx-react'
import {useStores} from "../../stores/useStores";
import {
  Row,
  Col,
  Input,
  Button,
  Table,
  Space,
  Drawer,
  Descriptions
} from 'antd';
import {SearchOutlined} from '@ant-design/icons';
import styles from './Ota.module.css'
import {data} from './test.data'

const OtaAfterSale: React.FC = () => {
  const {otaStore} =useStores()
  useEffect(()=>{
    (async function getData(){
      await otaStore.getOtaUpgradeCvInfo('LC0C34CG1K1019888')
    })()
  })

  const [visible, setVisible] = useState(false);
  const [rowDetails, setRowDetails] = useState({});
  const onClose = () => {
    setVisible(false);
  };

  const details = (record) => {
    setRowDetails(record)
    setVisible(true);
  }
  const columns = [
    {
      title: '车架号',
      dataIndex: 'vin',
      key: 'vin',
      width: 200,
    },
    {
      title: '车型',
      dataIndex: 'InnerCarType',
      key: 'InnerCarType',
      width: 100,
    },
    {
      title: '车辆升级结果',
      dataIndex: 'vehicleResult',
      key: 'vehicleResult',
      width: 100,
    },
    {
      title: '车辆版本',
      key: 'vehicleVersion',
      dataIndex: 'vehicleVersion',
      width: 100,
    },
    {
      title: '升级前版本',
      key: 'vehicleOriginVer',
      dataIndex: 'vehicleOriginVer',
      width: 100,
    },
    {
      title: '车辆升级时间',
      key: 'vehicleTime',
      dataIndex: 'vehicleTime',
      width: 150,
    },
    {
      title: '车辆升级原因',
      key: 'vehicleReasonSale',
      dataIndex: 'vehicleReasonSale',
      width: 400,
    },
    {
      title: '上报时间',
      key: 'requestDate',
      dataIndex: 'requestDate',
      width: 150,
    },
    {
      title: '更多',
      key: 'action',
      fixed: 'right',
      width: 80,
      render: (text, record) => (
        <Space size="middle">
          <a className={`${styles["action"]}`} onClick={() => details(record)}>详情</a>
        </Space>
      ),
    },
  ];
  return (
    <>
      <Row className={`${styles["search-row"]}`}>
        <Col span={4}>
          <Input placeholder="请输入车架号" suffix={<SearchOutlined/>}/>
        </Col>
        <Col span={8}>
          <Button type="primary">查询</Button>
          <Button>重置</Button>
        </Col>
      </Row>
      <Row>
        <Col span={24}>
          <Table size="middle" columns={columns}
                 dataSource={data} scroll={{x: 1200, y: 300}}/>
        </Col>
      </Row>
      <Drawer
        title="详情"
        placement="right"
        width={400}
        closable={false}
        onClose={onClose}
        visible={visible}
      >
        <Descriptions title="售后升级监控" column={1}>
          <Descriptions.Item label="车架号">{rowDetails.vin}</Descriptions.Item>
          <Descriptions.Item label="车型">{rowDetails.InnerCarType}</Descriptions.Item>
          <Descriptions.Item label="车辆升级结果">{rowDetails.vehicleResult}</Descriptions.Item>
          <Descriptions.Item label="车辆版本">{rowDetails.vehicleVersion}</Descriptions.Item>
          <Descriptions.Item label="升级前版本">{rowDetails.vehicleOriginVer}</Descriptions.Item>
          <Descriptions.Item label="车辆升级时间">{rowDetails.vehicleTime}</Descriptions.Item>
          <Descriptions.Item label="车辆升级原因">{rowDetails.vehicleReasonSale}</Descriptions.Item>
          <Descriptions.Item label="上报时间">{rowDetails.requestDate}</Descriptions.Item>
        </Descriptions>
      </Drawer>
    </>
  )
}

export default observer(OtaAfterSale)