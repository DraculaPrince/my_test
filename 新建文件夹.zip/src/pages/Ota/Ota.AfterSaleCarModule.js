import React, {useState} from 'react'
import {observer} from 'mobx-react'
import {
  Row,
  Col,
  Input,
  Button,
  Table,
  Space,
  Drawer,
  Descriptions
} from 'antd';
import {SearchOutlined} from '@ant-design/icons';
import styles from './Ota.module.css'
import {car_data} from './test.data'

const OtaAfterSaleCarModule: React.FC = () => {
  const [visible, setVisible] = useState(false);
  const [rowDetails, setRowDetails] = useState({});
  const onClose = () => {
    setVisible(false);
  };

  const details = (record) => {
    setRowDetails(record)
    setVisible(true);
  }
  const columns = [
    {
      title: '车架号',
      dataIndex: 'vin',
      key: 'vin',
      width: 200,
    },
    {
      title: '车型',
      dataIndex: 'InnerCarType',
      key: 'InnerCarType',
      width: 100,
    },
    {
      title: 'ECU名称',
      dataIndex: 'ecuName',
      key: 'ecuName',
      width: 100,
    },
    {
      title: '软件编码',
      key: 'ecuSoftCode ',
      dataIndex: 'ecuSoftCode',
      width: 100,
    },
    {
      title: '软件版本',
      key: 'ecuSoftVer',
      dataIndex: 'ecuSoftVer',
      width: 100,
    },
    {
      title: '升级时间',
      key: 'ecuTime',
      dataIndex: 'ecuTime',
      width: 150,
    },
    {
      title: '升级结果',
      key: 'ecuResult',
      dataIndex: 'ecuResult',
      width: 150,
    },
    {
      title: '升级前版本',
      key: 'ecuOriginSVer',
      dataIndex: 'ecuOriginSVer',
      width: 150,
    },
    {
      title: '升级原因',
      key: 'ecuReason',
      dataIndex: 'ecuReason',
      width: 400,
    },
    {
      title: '更多',
      key: 'action',
      fixed: 'right',
      width: 80,
      render: (text, record) => (
        <Space size="middle">
          <a className={`${styles["action"]}`} onClick={() => details(record)}>详情</a>
        </Space>
      ),
    },
  ];
  return (
    <>
      <Row className={`${styles["search-row"]}`}>
        <Col span={4}>
          <Input placeholder="请输入车架号" suffix={<SearchOutlined/>}/>
        </Col>
        <Col span={8}>
          <Button type="primary">查询</Button>
          <Button>重置</Button>
        </Col>
      </Row>
      <Row>
        <Col span={24}>
          <Table size="middle" columns={columns}
                 dataSource={car_data} scroll={{x: 1200, y: 300}}/>
        </Col>
      </Row>
      <Drawer
        title="详情"
        placement="right"
        width={400}
        closable={false}
        onClose={onClose}
        visible={visible}
      >
        <Descriptions title="售后车模块升级监控" column={1}>
          <Descriptions.Item label="车架号">{rowDetails.vin}</Descriptions.Item>
          <Descriptions.Item label="车型">{rowDetails.InnerCarType}</Descriptions.Item>
          <Descriptions.Item label="ECU名称">{rowDetails.ecuName}</Descriptions.Item>
          <Descriptions.Item label="软件编码">{rowDetails.ecuSoftCode}</Descriptions.Item>
          <Descriptions.Item label="软件版本">{rowDetails.ecuSoftVer}</Descriptions.Item>
          <Descriptions.Item label="升级时间">{rowDetails.ecuTime}</Descriptions.Item>
          <Descriptions.Item label="升级结果">{rowDetails.ecuResult}</Descriptions.Item>
          <Descriptions.Item label="升级前版本">{rowDetails.ecuOriginSVer}</Descriptions.Item>
          <Descriptions.Item label="升级原因">{rowDetails.ecuReason}</Descriptions.Item>
        </Descriptions>
      </Drawer>
    </>
  )
}

export default observer(OtaAfterSaleCarModule)