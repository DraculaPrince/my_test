import React, { lazy } from 'react'
import {Route} from 'react-router-dom'
import Loading from './pages/Loading'
import Icall from './pages/Icall'

const ServiceInfo = lazy(()=> import('./pages/ServiceInfo'))
const Ota = lazy(()=> import('./pages/Ota'))
const Dealer = lazy(()=> import('./pages/Dealer'))

export const RouteWithSubRoutes = (route) => {
	return (
		<Route
			path={route.path}
			render={props => (
				<route.component {...props} routes={route.routes}/>
			)}
		/>
	)
}

const routes = [
	{
		path: '/dealer',
		component: Dealer,
	},
	{
		path: '/ota',
		component: Ota,
	},
	{
		path: '/serviceInfo',
		component: ServiceInfo,
	},
	{
		path: '/icall',
		component: Icall,
	},
	{
		path: '/',
		component: Loading,
		exact: true
	}
]

export default routes