import React, { Suspense } from 'react'
import { useLocalStore } from 'mobx-react'
import { HashRouter as Router } from 'react-router-dom'
import App from './App'
import { storesContext } from './stores/context'
import { publicStores } from './stores/useStores'

const Root: React.FC = () => {
	const useStore = useLocalStore(()=>publicStores())
	return (
		<storesContext.Provider value={useStore}>
			<Router>
				<Suspense fallback={null}>
					<App />
				</Suspense>
			</Router>
		</storesContext.Provider>
	)
}

export default Root