const { override, fixBabelImports, addPostcssPlugins } = require(
	'customize-cra')

module.exports = override(
	fixBabelImports('import', {
		libraryName: 'antd',
		libraryDirectory: 'es',
		style: 'css',
	}),
	addPostcssPlugins([require('postcss-pxtorem')({
		rootValue: 144,
		propList: ['*'],
		minPixelValue: 2,
		selectorBlackList: ['am-'], // 忽略antd相关的css
	})]),
)